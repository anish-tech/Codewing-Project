
	<?php if(is_page('contact')) {?>
	<?php } else { ?>
	<section class="newsletter-section">
		<div class="footer-newsletter-wrap">
			<div class="container">
				<div class="col-sm-12">
					<p class="newsletter_text">Join my mailing list to have text emails sent about new posts. Sometimes you get something special</p>
					<div class="newsletter_form">
						<?php echo do_shortcode( '[contact-form-7 id="163" title="Footer Newsletter"]' ); ?>
					</div>
				</div>
			</div>
		</div>
	</section> <!-- .newsletter-section -->
	<?php }?>
		
		<footer class="site-footer">
			<div class="top-footer">
				<div class="container">
					<div class="col">
						<section class="widget widget_text">
							<?php dynamic_sidebar( 'About' ); ?>
						</section>
					</div>
					<div class="col">
						<section class="widget widget_recent_entries">		
							<?php dynamic_sidebar( 'Footer Recent Posts' ); ?>
						</section>
					</div>
					<div class="col">
						<section class="widget widget_categories">
						<?php dynamic_sidebar( 'Footer Category' ); ?>
						</section>
					</div>
				</div>
			</div> <!-- .top-footer -->
			<div class="bottom-footer">
				<div class="container footer_container">
					<div class="copyright">            
						<span>© <?php echo the_date('Y');?> <a href="#">Super Ultra Light</a> - All Rights Reserved. </span><a href="#" target="_blank"> Super Ultra Light</a> by Rara Themes. Powered by <a href="https://wordpress.com/" target="_blank">WordPress</a>. <a class="privacy-policy-link" href="<?php bloginfo('url')?>/sample-page">Privacy Policy</a>               
					</div>
					<div class="footer-social">
						<ul class="social-list">
							<li><a data-title="facebook" href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
							<li><a data-title="twitter" href="https://twitter.com/" target="_blank"><i class="fab fa-twitter"></i></a></li>
							<li><a data-title="google-plus" href="https://www.gmail.com/" target="_blank"><i class="fab fa-google-plus-g"></i></a></li>
							<li><a data-title="linkedin" href="https://www.linkedin.com/" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
							<li><a data-title="pinterest" href="https://www.pinterest.com/" target="_blank"><i class="fab fa-pinterest"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</footer> <!-- .site-footer -->
	</div> <!-- #page -->

	<!-- JS FILES -->
	<script type="text/javascript" src="<?php bloginfo('template_url') ;?>/js/jquery-1.12.0.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url') ;?>/js/custom.js"></script>
	<script>
		 if (window.location.href.indexOf("page") > -1){
			var elmnt = document.getElementById("blog-container");
			elmnt.scrollIntoView();
		 }
	</script>	
</body>
<?php wp_footer(); ?>
</html>
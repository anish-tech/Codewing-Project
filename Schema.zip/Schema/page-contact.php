<?php get_header() ;?>

<section id="inner-banner" class="contact imgss">
    	<div class="banner-bg"></div><!--banner-bg-->
        <div class="banner-content">
            <div class="banner-holder">
                <div class="container inner-container">
                    <div class="row">
                        <div class="col-sm-12 text-center">
                            <div class="banner-text">
                                <h1>We’re Here To Help.<span> Let’s Talk.</h1>
                            </div><!--banner-text-->
                            <div class="contact-wrap">
							<div class="map-wrap">
								<h3 class="location">{location}</h3>
								<h3 class="phone">Phone : {phone} </h3>
								<h3 class="email">Email : {email} </h3>                                
							</div><!--map-wrap-->
							</div><!--contact-wrap-->
							<div class="contact-form-wrap">
							<?php echo do_shortcode( '[contact-form-7 id="162" title="Contact Us Form"]' ); ?>
							</div>
                        </div><!--col-sm-12-->
                    </div><!--row-->
                </div><!--container-->
            </div><!--banner-holder-->
        </div><!--banner-content-->		
	</section>
	
<?php get_footer() ;?>
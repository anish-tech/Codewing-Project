<?php get_header();?>
	
	<div id="inner-section">
	<?php $inner_banner_image = get_field('inner_banner_image'); 
	if (!empty($inner_banner_image)) { ?>
	<div class="inner-img" style="background-image:url('<?php echo $inner_banner_image; ?>');">
	<?php } else { ?>
	<div class="inner-img">
		<div class="container container-md">
			<div class="row">
				<div class="col-sm-12">
					<div class="inner-wrap">
						<div class="title_content">
							<h1><?php if(is_page()) { ?> 
							<?php the_title(); ?> 
							<?php } elseif (is_single()) { ?> 
							<?php the_title();?>
							<?php } elseif (is_archive()){?>
							<?php echo post_type_archive_title( '', false ); ?>
							<?php } elseif (is_404()){?>
							Oops! Page Not Found 
							<?php } elseif (is_search()){?>
							Search results for: <?php the_search_query(); ?>
							<?php }?></h1>
							<?php 
							if ( has_excerpt() ) {
							the_excerpt(); 
							}
							?>     
						<?php }?>
						</div>
						</div>
					</div><!-- inner-wrap -->
				</div><!-- col-sm-12 -->
			</div><!-- row -->
		</div><!-- container -->     
	</div><!-- inner-section-->

		<div id="blog-container" class="container">
			<div id="primary inner" class="content-area">
				<main id="main" class="site-main">
				<?php
				if ( have_posts()) : while( have_posts()) : the_post();
				$postid = $post->ID; 

				?>  
					<article  class="post">
						<figure class="post-thumbnail inner">
							<?php the_post_thumbnail(''); ?>    
						</figure>
						<div class="post-content-wrap">
							<header class="entry-header">
							<div class="entry-meta">
								<span class="posted-on" itemprop="datePublished">
									<a>
									<time datetime="2017-12-21"><?php echo date('M j, Y') ;?></time>
									</a>
								</span>
								<span class="category">
									<?php
									echo get_the_tag_list('<span>','','</span>');
									?>
								</span>
							</div>
							<h2 class="entry-title" itemprop="headline">
							<a href="<?php the_permalink() ;?>"><?php the_title() ;?></a>
							</h2>
							</header>
							<div class="entry-content">
								<?php the_excerpt() ;?>
							</div>
							<footer class="entry-footer">
								<a href="<?php the_permalink() ;?>" class="btn-readmore">Continue Reading</a>
							</footer>
						</div>
					</article>
					<?php endwhile; ?>
						<div id="pagination">
						<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } ?> 
						</div> 
						<?php else : ?>             
						<div class="no_records"><b>Sorry, but you are looking for something that isn't here. please try again later</div>
						<?php 
						endif; 
						wp_reset_query(); ?> 
				</main> <!-- .site-main -->
			</div>
		</div> <!-- #primary -->

		<div id="content-page">
			<div class="container inner-container">
				<div class="row">
					<div class="col-sm-12 text-center">
						<div class="content-wrapper">
							<div class="body-content">
								<?php  
								if ( have_posts() ) : while ( have_posts() ) : the_post(); 
								$backgroundImage = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID())); 
								?>   
									<?php the_content();?> 
								<?php endwhile; endif;wp_reset_query(); ?>  
							</div><!--body-content-->
						</div><!--content-wrapper-->
					</div><!--col-sm-12-->
				</div><!--row-->
			</div><!--container-->
		</div><!--content-page-->

<?php get_footer() ;?>
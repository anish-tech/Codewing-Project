<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>.::SUPER ULTRA THEME | HOMEPAGE::.</title>
	<link href="https://fonts.googleapis.com/css?family=Abhaya+Libre:400,500,600,700,800|Nunito+Sans:400,400i,600,600i,700,700i" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/fontawesome-all.css">
	<link rel="stylesheet" type="text/css" href="css/raratheme-companion-public.css">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body class="error404 full-width">
	<div id="page" class="site">
		<header class="site-header">
			<div class="container">
				<div class="menu-toggle">
					<span class="toggle-bar"></span>
					<span class="toggle-bar"></span>
					<span class="toggle-bar"></span>
				</div>
				<div class="site-branding logo-text">
					<div class="site-logo">
						<a href="index.html" title="Super Ultra Theme">
							<img src="images/site-logo.png" alt="super ultra theme">
						</a>
					</div>
					<div class="site-text-wrap">
						<h1 class="site-title">
							<a href="index.html" title="Super Ultra Theme">SuperUltraTheme</a>
						</h1>
						<p class="site-description">Just Another WordPress Theme</p>
					</div>
				</div> <!-- .site-branding -->
				<div class="menu-wrap">
					<nav class="main-navigation">
						<button class="menu-toggle">
							<span class="toggle-bar"></span>
							<span class="toggle-bar"></span>
							<span class="toggle-bar"></span>
						</button>
						<ul class="nav-menu">
							<li class="current-menu-item">
								<a href="index.html">Home</a>
							</li>
							<li>
								<a href="#">About</a>
							</li>
							<li class="menu-item-has-children">
								<a href="#">Services</a>
								<ul class="sub-menu">
									<li>
										<a href="#">Child Menu One</a>
									</li>
									<li class="menu-item-has-children">
										<a href="#">Child Menu Two</a>
										<ul class="sub-menu">
											<li>
												<a href="#">Grandchild Menu One</a>
											</li>
											<li>
												<a href="#">Grandchild Menu Two</a>
											</li>
											<li>
												<a href="#">Grandchild Menu Three</a>
											</li>
											<li>
												<a href="#">Grandchild Menu Four</a>
											</li>
										</ul>
									</li>
									<li>
										<a href="#">Child Menu Three</a>
									</li>
									<li>
										<a href="#">Child Menu Four</a>
									</li>
								</ul>
							</li>
							<li>
								<a href="#">Blog</a>
							</li>
							<li class="menu-item-has-children">
								<a href="#">Contact</a>
								<ul class="sub-menu">
									<li>
										<a href="#">Child Menu One</a>
									</li>
									<li class="menu-item-has-children">
										<a href="#">Child Menu Two</a>
										<ul class="sub-menu">
											<li>
												<a href="#">Grandchild Menu One</a>
											</li>
											<li>
												<a href="#">Grandchild Menu Two</a>
											</li>
											<li>
												<a href="#">Grandchild Menu Three</a>
											</li>
											<li>
												<a href="#">Grandchild Menu Four</a>
											</li>
										</ul>
									</li>
									<li>
										<a href="#">Child Menu Three</a>
									</li>
									<li>
										<a href="#">Child Menu Four</a>
									</li>
								</ul>
							</li>
						</ul>
					</nav>
					<div class="header-search">
						<span class="search-toggle">
							<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18"><defs><style>.a{fill:none;}</style></defs><g transform="translate(83 -7842)"><rect class="a" width="18" height="18" transform="translate(-83 7842)"/><path d="M18,16.415l-3.736-3.736a7.751,7.751,0,0,0,1.585-4.755A7.876,7.876,0,0,0,7.925,0,7.876,7.876,0,0,0,0,7.925a7.876,7.876,0,0,0,7.925,7.925,7.751,7.751,0,0,0,4.755-1.585L16.415,18ZM2.264,7.925a5.605,5.605,0,0,1,5.66-5.66,5.605,5.605,0,0,1,5.66,5.66,5.605,5.605,0,0,1-5.66,5.66A5.605,5.605,0,0,1,2.264,7.925Z" transform="translate(-83 7842)"/></g></svg>
						</span>
						<div class="header-search-form">
							<div class="container">
								<form role="search" method="get" class="search-form" action="">
									<label>
										<span class="screen-reader-text">Search for:</span>
										<input class="search-field" placeholder="Search anything and hit enter" value="" name="s" type="search">
									</label>
									<input class="search-submit" value="Search" type="submit">
								</form>
								<span class="close"></span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header> <!-- .site-header -->

		<div id="content" class="site-content">			
			<div class="container">
				<div id="primary" class="content-area">
					<main id="main" class="site-main">
						<section class="error-404 not-found">
							<header class="page-header">
								<h1 class="page-title">Uh-Oh...</h1>
								<div class="page-desc">
									The page you are looking for may have been moved, deleted, or possibly never existed.
								</div>
							</header>
							<div class="page-content">
								<div class="error-num">404</div>
								<a class="bttn" href="index.html">Take me to the home page</a>
								<form role="search" method="get" class="search-form" action="">
									<label>
										<span class="screen-reader-text">Search for:</span>
										<input class="search-field" placeholder="Try searching for what you were looking for..." value="" name="s" type="search">
									</label>
									<input class="search-submit" value="Search" type="submit">
								</form>				
							</div><!-- .page-content -->
						</section>
					</main> <!-- .site-main -->
				</div> <!-- #primary -->
			</div> <!-- .container -->
			<div class="additional-posts">
				<div class="container">
					<h3 class="title">
						Recommended Articles
					</h3>			
					<div class="block-wrap">
						<div class="block clearfix">
							<div class="entry-meta">
								<span class="posted-on" itemprop="datePublished">
									<a href="#">
										<time datetime="2017-12-21">Feb 18, 2018</time>
									</a>
								</span>
							</div>
							<header class="entry-header">
								<h3 class="entry-title">
									<a href="#">This Start-Up Will Actually Downsize Your Closet</a>
								</h3>                        
							</header><!-- .entry-header -->
							<figure class="post-thumbnail">
								<a href="#">
									<img src="images/blog-img1.jpg" alt="">                    
								</a>
							</figure><!-- .post-thumbnail -->
						</div>
						<div class="block clearfix">
							<div class="entry-meta">
								<span class="posted-on" itemprop="datePublished">
									<a href="#">
										<time datetime="2017-12-21">Feb 18, 2018</time>
									</a>
								</span>
							</div>
							<header class="entry-header">
								<h3 class="entry-title">
									<a href="#">Tesla Ramps Up Model 3 Production and Predicts Profitability</a>
								</h3>                        
							</header><!-- .entry-header -->
							<figure class="post-thumbnail">
								<a href="#">
									<img src="images/blog-img2.jpg" alt="">                    
								</a>
							</figure><!-- .post-thumbnail -->
						</div>
						<div class="block clearfix">
							<div class="entry-meta">
								<span class="posted-on" itemprop="datePublished">
									<a href="#">
										<time datetime="2017-12-21">Feb 18, 2018</time>
									</a>
								</span>
							</div>
							<header class="entry-header">
								<h3 class="entry-title">
									<a href="#">7 Off-Duty Outfits That Will Reinvent Your Spring Wardrobe</a>
								</h3>                        
							</header><!-- .entry-header -->
							<figure class="post-thumbnail">
								<a href="#">
									<img src="images/blog-img3.jpg" alt="">                    
								</a>
							</figure><!-- .post-thumbnail -->
						</div>
					</div><!-- .block-wrap -->
				</div>
			</div>
		</div> <!-- .site-content -->

		<section class="newsletter-section">
			<img src="images/newsletter-section.jpg" alt="">
		</section> <!-- .newsletter-section -->

		<footer class="site-footer">
			<div class="top-footer">
				<div class="container">
					<div class="col">
						<section class="widget widget_text">
							<h2 class="widget-title">About</h2>
							<div class="textwidget">
								<p>All seven continents by 30, I wrote. I wanted to be the person that could say that. On December 16th...</p>
							</div>
						</section>
					</div>
					<div class="col">
						<section class="widget widget_recent_entries">		
							<h2 class="widget-title" itemprop="name">Recent Posts</h2>		
							<ul>
								<li>
									<a href="#">Exploring Untravelled Destinations</a>
									<span class="post-date">February 12, 2018</span>
								</li>
								<li>
									<a href="#">This theme recommends the following plugins</a>
									<span class="post-date">February 12, 2018</span>
								</li>
								<li>
									<a href="#">Hello world!</a>
									<span class="post-date">November 22, 2017</span>
								</li>
							</ul>
						</section>
					</div>
					<div class="col">
						<section class="widget widget_categories">
							<h2 class="widget-title" itemprop="name">Categories</h2>
							<ul>
								<li class="cat-item"><a href="#">Entertainment</a> (1)</li>
								<li class="cat-item"><a href="#">Finance</a> (2)</li>
								<li class="cat-item"><a href="#">Politics</a> (2)</li>
								<li class="cat-item"><a href="#">Uncategorized</a> (3)</li>
							</ul>
						</section>
					</div>
				</div>
			</div> <!-- .top-footer -->
			<div class="bottom-footer">
				<div class="container">
					<div class="copyright">            
						<span>© 2018 <a href="#">Super Ultra Light</a> - All Rights Reserved. </span><a href="#" target="_blank"> Super Ultra Light</a> by Rara Themes. Powered by <a href="#" target="_blank">WordPress</a>. <a class="privacy-policy-link" href="#">Privacy Policy</a>               
					</div>
					<div class="footer-social">
						<ul class="social-list">
							<li><a data-title="facebook" href="#"><i class="fab fa-facebook-f"></i></a></li>
							<li><a data-title="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
							<li><a data-title="google-plus" href="#"><i class="fab fa-google-plus-g"></i></a></li>
							<li><a data-title="linkedin" href="#"><i class="fab fa-linkedin-in"></i></a></li>
							<li><a data-title="pinterest" href="#"><i class="fab fa-pinterest"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</footer> <!-- .site-footer -->
	</div> <!-- #page -->

	<!-- JS FILES -->
	<script type="text/javascript" src="js/jquery-1.12.0.js"></script>
	<script type="text/javascript" src="js/custom.js"></script>
</body>
</html>
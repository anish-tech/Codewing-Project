<?php
/**
 * topnotchnetworking_ulistic functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package topnotchnetworking_ulistic
 */
function schema_scripts() {
}
// This theme uses wp_nav_menu() in one location.
register_nav_menu('main-menu',__( 'Main Menu' ));

add_theme_support( 'post-thumbnails' );


/****************************/



/************** Home Post Type****************/
function home_banner() {
    register_post_type('home_banner', array(
      'supports' => array('title', 'editor', 'excerpt','author', 'thumbnail', 'comments', 'revisions', 'custom-fields'),
      'rewrite' => array('slug' => 'home_banner'),
      'has_archive' => true,
      'public' => true,
      'labels' => array(
        'name' => 'Home Banner',
        'add_new_item' => 'Add New Banner',
        'edit_item' => 'Edit Banner',
        'all_items' => 'All Home Banners',
        'singular_name' => 'Home Banner',
      ), 
      'menu_icon' => 'dashicons-testimonial'
    ));
  }
  add_action('init', 'home_banner');

  

/************** Services Post Type****************/
function services() {
    register_post_type('services', array(
      'supports' => array('title', 'editor', 'excerpt','author', 'thumbnail', 'comments', 'revisions', 'custom-fields'),
      'rewrite' => array('slug' => 'services'),
      'has_archive' => true,
      'public' => true,
      'labels' => array(
        'name' => 'Services',
        'add_new_item' => 'Add New Services',
        'edit_item' => 'Edit Services',
        'all_items' => 'All Services',
        'singular_name' => 'Services',
      ), 
      'menu_icon' => 'dashicons-testimonial'
    ));
  }
  add_action('init', 'services');


  

/************** Partners Post Type****************/
function partners() {
    register_post_type('partners', array(
      'supports' => array('title', 'editor', 'excerpt','author', 'thumbnail', 'comments', 'revisions', 'custom-fields'),
      'rewrite' => array('slug' => 'home_banner'),
      'has_archive' => true,
      'public' => true,
      'labels' => array(
        'name' => 'Partners',
        'add_new_item' => 'Add New Partner',
        'edit_item' => 'Edit Partner',
        'all_items' => 'All Partners',
        'singular_name' => 'Partners',
      ), 
      'menu_icon' => 'dashicons-testimonial'
    ));
  }
  add_action('init', 'partners');


  

/************** Get Help Post Type****************/
function get_help() {
    register_post_type('get_help', array(
      'supports' => array('title', 'editor', 'excerpt','author', 'thumbnail', 'comments', 'revisions', 'custom-fields'),
      'rewrite' => array('slug' => 'get_help'),
      'has_archive' => true,
      'public' => true,
      'labels' => array(
        'name' => 'Get Help',
        'add_new_item' => 'Add New Get Help',
        'edit_item' => 'Edit Get Help',
        'all_items' => 'All Get Help',
        'singular_name' => 'Get Help',
      ), 
      'menu_icon' => 'dashicons-testimonial'
    ));
  }
  add_action('init', 'get_help');


/**************Testimonial Post Type****************/
function testimonials() {
    register_post_type('testimonials', array(
      'supports' => array('title', 'editor', 'excerpt','author', 'thumbnail', 'comments', 'revisions', 'custom-fields'),
      'rewrite' => array('slug' => 'testimonials'),
      'has_archive' => true,
      'public' => true,
      'labels' => array(
        'name' => 'Testimonials',
        'add_new_item' => 'Add New Testimonial',
        'edit_item' => 'Edit Testimonial',
        'all_items' => 'All Testimonials',
        'singular_name' => 'Testimonial',
      ), 
      'menu_icon' => 'dashicons-testimonial'
    ));
  }
  add_action('init', 'testimonials');

  
/******footer-widget-sidebar******/
if (function_exists('register_sidebar')):
    register_sidebar(array(
      'name'      => 'Contact',
      'before_widget' => '',
      'after_widget' => '',
      'before_title' => '<h4>',
      'after_title' => '</h4>',
    ));

    register_sidebar(array(
        'name'      => 'Artical Evidence',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
      ));
    
      
    register_sidebar(array(
        'name'      => 'Blog',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '<h1 class="page-title">',
        'after_title' => '</h1>',
      ));
      register_sidebar(array(
        'name'      => 'Search',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '<h4>',
        'after_title' => '</h4>',
      ));
   
      register_sidebar(array(
        'name'      => 'About',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
      ));    

      
      register_sidebar(array(
        'name'      => 'Footer Recent Posts',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
      ));  
      
      register_sidebar(array(
        'name'      => 'Footer Category',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
      ));  
      
  endif;
  add_action( 'init', 'my_add_excerpts_to_pages' );
  function my_add_excerpts_to_pages() {
       add_post_type_support( 'page', 'excerpt' );
  } 

?>
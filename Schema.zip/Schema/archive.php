<?php get_header('category'); ?> 
<div id="content" class="site-content">
	<header class="page-header">
		<div class="container">
			<?php dynamic_sidebar( 'Blog' ); ?>
		</div>
	</header>
<div class="container">
	<div id="primary" class="content-area inner">
		<main id="main" class="site-main">
			<?php
			if ( have_posts()) : while( have_posts()) : the_post();
			$postid = $post->ID;?>  
				<article class="post">
					<figure class="post-thumbnail">
						<?php the_post_thumbnail(''); ?>    
					</figure>
					<div class="post-content-wrap">
						<header class="entry-header">
							<div class="entry-meta">
								<span class="posted-on" itemprop="datePublished">
									<a>
										<time datetime="2017-12-21"><?php echo date('M j, Y') ;?></time>
									</a>
								</span>
								<span class="category">
									<?php
										echo get_the_tag_list('<span>','','</span>');
									?>
								</span>
							</div><!--entry-meta -->
							<h2 class="entry-title" itemprop="headline">
								<a href="<?php the_permalink() ;?>"><?php the_title() ;?></a>
							</h2>
						</header>
						<div class="entry-content">
							<?php the_excerpt() ;?>
						</div>
						<footer class="entry-footer">
							<a href="<?php the_permalink() ;?>" class="btn-readmore">Continue Reading</a>
						</footer>
					</div>
				</article>
			<?php
			endwhile; ?>
				<div class="page">
					<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } ?>  
				</div><!--page-->
			<?php else : ?> 
			<?php
			/* endwhile;*/
			endif;
			//Reset Query
			wp_reset_query();
			?>
		</main> <!-- .site-main -->
	</div> <!-- #primary -->
<?php get_footer ();?>
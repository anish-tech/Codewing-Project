<?php get_header ();?>

	<div class="site-banner">
		<?php
		query_posts('post_type=home_banner&posts_per_page=1');
		if( have_posts()) : while( have_posts()) : the_post();
		?>
			<div class="banner-item">
			<img src="<?php the_post_thumbnail_url();?>" alt="banner">
				<div class="banner-caption center">
					<div class="container">
						<h1 class="title">
							<a href="<?php the_permalink(); ?>"><?php the_title() ;?></a>
						</h1>
					<!-- <div class="item-desc banner_form"> -->
					<?php the_excerpt() ;?>
						<div class="banner_form">
							<?php echo do_shortcode( '[contact-form-7 id="160" title="Form"]' ); ?>
						</div><!-- banner-item -->
					</div><!-- container -->
				</div><!-- banner-caption -->
			</div><!-- banner-item -->
		<?php
		endwhile;
		endif;
		//Reset Query
		wp_reset_query();									
		?> 
	</div> <!-- .site-banner -->

	<section class="about-section">
		<div class="container">
			<section class="widget widget_raratheme_featured_page_widget">                
				<div class="widget-featured-holder right">
					<p class="section-subtitle">                        
						<span>About Us</span>
					</p>                   
					<?php
					query_posts('post_type=testimonials&posts_per_page=1');
					if( have_posts()) : while( have_posts()) : the_post();
					$backgroundImage = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()));
					?> 
						<div class="text-holder">
						<h2 class="widget-title"><?php the_title() ;?></h2>
							<div class="featured_page_content">
							<p><?php the_content() ;?></p>
							<a href="<?php the_permalink (); ?>" target="_blank" class="btn-readmore">Know more about me</a>
							</div><!--featured_page_content-->
						</div><!--text-holder-->
						<div class="img-holder">
							<a target="_blank" href="#">
								<?php the_post_thumbnail(''); ?>                   
							</a>
						</div><!--text-holder-->
					<?php
					endwhile;
					endif;
					//Reset Query
					wp_reset_query();									
					?> 
				</div><!-- widget-featured-holder -->     
			</section>
		</div><!-- container -->
	</section> <!-- .about-section -->

	<section class="client-section">
		<div class="container">
			<section class="widget widget_raratheme_client_logo_widget">            
				<div class="raratheme-client-logo-holder">
					<div class="raratheme-client-logo-inner-holder">
					<h2 class="widget-title" itemprop="name">Raushan has been featured on:</h2>                             
						<div class="image-holder-wrap"> <!-- yo wrap plugin ko filter bata rakhnu parxa -->
							<?php
							query_posts('post_type=partners&posts_per_page=-1');
							if( have_posts()) : while( have_posts()) : the_post();
							?>
								<div class="image-holder black-white">
									<a href="#" target="_blank">
									<img src="<?php the_field('partner_image') ;?>" alt="<?php the_title_attribute() ;?>">  
									</a> 
								</div>
							<?php
							endwhile;
							endif;
							//Reset Query
							wp_reset_query();									
							?> 
						</div>
					</div><!--raratheme-client-logo-inner-holder-->
				</div><!--raratheme-client-logo-holder-->
			</section><!--section-->
		</div><!--container-->
	</section> <!-- client-section -->

	<section class="service-section">
		<div class="container">
			<section class="widget widget_text">
				<?php dynamic_sidebar( 'Artical Evidence' ); ?>
			</section>
			<?php
			query_posts('post_type=get_help&posts_per_page=-1');
			if( have_posts()) : while( have_posts()) : the_post();
			$backgroundImage = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()));
			?> 
				<section class="widget widget_rrtc_icon_text_widget">        
					<div class="rtc-itw-holder">
						<div class="rtc-itw-inner-holder">
							<div class="text-holder">
							<h2 class="widget-title" itemprop="name"><?php the_title() ;?></h2>
								<div class="content">
									<?php the_excerpt() ;?>
								</div><!--conent-->
							<a class="btn-readmore" href="<?php the_permalink() ;?>" target="_blank">Learn More</a>                              
							</div><!--text-holder-->
							<div class="icon-holder">
								<img src="<?php the_field('get_help_icon') ;?>" alt="<?php the_title_attribute() ;?>">  
							</div>
						</div><!--rtc-itw-inner-holder-->
					</div><!--rtc-itw-holde-->
				</section>
			<?php
			endwhile;
			endif;
			//Reset Query
			wp_reset_query();									
			?> 
		</div><!-- container -->
	</section> <!-- .service-section -->

	<div id="content" class="site-content">
		<header class="page-header">
			<div class="container">
				<?php dynamic_sidebar( 'Blog' ); ?>
			</div>
		</header>

		<div id="blog-container" class="container">
			<div id="primary" class="content-area">
				<main id="main" class="site-main">
					<?php
					query_posts('posts_per_page=3&category_name=blog&paged=' . $paged);   
					if ( have_posts()) : while( have_posts()) : the_post();
					$postid = $post->ID; 
					?>  
						<article  class="post">
							<figure class="post-thumbnail">
								<?php the_post_thumbnail(''); ?>    
							</figure>
							<div class="post-content-wrap">
								<header class="entry-header">
									<div class="entry-meta">
										<span class="posted-on" itemprop="datePublished">
											<a>
												<time datetime="2017-12-21"><?php echo date('M j, Y') ;?></time>
											</a>
										</span>
										<span class="category">
											<?php
												echo get_the_tag_list('<span>','','</span>');
											?>
										</span>
									</div>
									<h2 class="entry-title" itemprop="headline">
										<a href="<?php the_permalink() ;?>"><?php the_title() ;?></a>
									</h2>
								</header>
								<div class="entry-content">
									<?php the_excerpt() ;?>
								</div>
								<footer class="entry-footer">
									<a href="<?php the_permalink() ;?>" class="btn-readmore">Continue Reading</a>
								</footer>
							</div>
						</article>
					<?php
					endwhile; ?>
						<div class="page">
							<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } ?>  
						</div><!--page-->
					<?php else : ?> 
					<?php
					/* endwhile;*/
					endif;
					//Reset Query
					wp_reset_query();
					?>
				</main> <!-- .site-main -->

			</div> <!-- #primary -->
			<aside id="secondary" class="widget-area">
				<section class="widget widget_search">
					<?php dynamic_sidebar( 'Search' ); ?>
				</section>
			</aside> <!-- #secondary -->
		</div> <!-- .container -->
	</div> <!-- .site-content -->

	
<?php get_footer() ;?>
<?php get_header('inner'); ?> 
<div id="content-page">
    	<div class="container inner-container">
        	<div class="row">
            	<div class="col-sm-12 text-center">
                	<div class="content-wrapper">
                    	<div class="body-content">
                           <?php  
                if ( have_posts() ) : while ( have_posts() ) : the_post(); 
                $backgroundImage = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID())); 
                ?>   
						<?php the_content(); ?> 
                   <?php endwhile; endif;wp_reset_query(); ?>  
                            <div class="profile-content">
                            
                            </div><!--profile-content-->
                         </div><!--body-content-->
                    </div><!--content-wrapper-->
                </div><!--col-sm-12-->
            </div><!--row-->
        </div><!--container-->
	</div><!--content-page-->
	<?php get_footer() ;?>